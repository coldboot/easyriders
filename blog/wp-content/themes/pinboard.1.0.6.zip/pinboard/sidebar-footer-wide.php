<?php if( is_active_sidebar( 10 ) ) : ?>
	<div id="sidebar-footer-wide" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 10 ) ; ?>
		<div class="clear"></div>
	</div><!-- #sidebar-home -->
<?php endif; ?>