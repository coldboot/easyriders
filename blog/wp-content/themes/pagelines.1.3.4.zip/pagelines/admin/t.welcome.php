<?php
/**
 * Welcome include, a child theme can override this by simply adding a welcome.php to its root folder.
 *
 */
