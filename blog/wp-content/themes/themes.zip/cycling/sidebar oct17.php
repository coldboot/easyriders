<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td><table width="220" border="0" align="center" cellpadding="0" cellspacing="0">
					
					<tr><td>	  <?php 
	if ( ! dynamic_sidebar( 'primary-widget-area' ) ) : ?>
<?php endif; // end primary widget area ?>

</td></tr>
                   <!--   <tr>
                        <td class="head_yellow">Popular posts</td>
                      </tr>
                      <tr> 
                        <td><table width="97%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td height="5" colspan="2"></td>
                            </tr>
                          <tr>
                            <td width="85"><img src="<?php bloginfo('template_directory'); ?>/images/ima2.png" width="78" height="63" /></td>
                            <td class="body_text_gray">Lorem ipsum dolor sit amet, consec tetuer adipiscing elit. Praesent </td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td align="right" class="body_text_gray"><a href="#" class="a">Readmore</a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td><table width="220" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td class="head_yellow">Blogger news</td>
                      </tr>
                      <tr>
                        <td><table width="97%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td height="5"></td>
                            </tr>
                            <tr>
                              <td width="85" class="body_text_gray">Lorem ipsum dolor sit amet, consec tetuer adipiscing elit </td>
                              </tr>
                            <tr>
                              <td align="right"><a href="#" class="red">&gt;&gt;</a></td>
                              </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td><table width="97%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td height="5"></td>
                          </tr>
                          <tr>
                            <td width="85" class="body_text_gray">Lorem ipsum dolor sit amet, consec tetuer adipiscing elit </td>
                          </tr>
                          <tr>
                            <td align="right"><a href="#" class="red">&gt;&gt;</a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td><table width="97%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td height="5"></td>
                          </tr>
                          <tr>
                            <td width="85" class="body_text_gray">Lorem ipsum dolor sit amet, consec tetuer adipiscing elit </td>
                          </tr>
                          <tr>
                            <td align="right"><a href="#" class="red">&gt;&gt;</a></td>
                          </tr>
                        </table></td>
                      </tr>
                      
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td><table width="220" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td class="head_yellow">Blog Archive</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                    <td class="body_text_gray">&gt;&gt;2011 (May 1)</td>
                  </tr>
                  <tr>
                    <td class="body_text_gray">&gt;&gt;2011 (May 10 )</td>
                  </tr>
                  <tr>
                    <td class="body_text_gray">&gt;&gt;2011 (May 18 )</td>
                  </tr>
                  <tr>
                    <td class="body_text_gray">&gt;&gt;2011 (May 20 )</td>
                  </tr>
                  <tr>
                    </table></td>
                  </tr>-->
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td><table width="220" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td class="head_yellow">Follow Us on </td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td><table border="0" align="center" cellpadding="3" cellspacing="0">
                          <tr>
                            <td><a href="http://www.facebook.com"><img src="<?php bloginfo('template_directory'); ?>/images/facebook.png" width="28" height="29" border="0" /></a></td>
                            <td><a href="http://www.rss.com"><img src="<?php bloginfo('template_directory'); ?>/images/rss.png" width="28" height="28" border="0" /></a></td>
                            <td><a href="http://www.twitter.com"><img src="<?php bloginfo('template_directory'); ?>/images/twitter.png" width="28" height="29" border="0" /></a></td>
                          </tr>
                        </table></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="355">&nbsp;</td>
                  </tr>
                </table>