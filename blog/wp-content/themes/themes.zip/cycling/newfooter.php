<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">

      <tr>

        <td height="90" align="center" class="white_text">Copyrights &copy; 2011-2013<a href="/index.php" style="text-decoration:none; color:#666;"> sydney-easy-riders.com.au</a> All Rights Reserved. </td>

        </tr>

    </table>