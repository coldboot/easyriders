<table width="99%" border="0" align="left" cellpadding="0" cellspacing="0">
                  <tr>
                    <td class="body_text">&nbsp;</td>
                  </tr>
                  <tr>
                    <td class="body_text">Register Here </td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td>
					<table>
					<tr><td> Email Id </td><td>: </td><td> <input type="text" name="emailid" value=""></td></tr>
					<tr><td> Email Id </td><td>: </td><td> <input type="text" name="emailid" value=""></td></tr>
					<tr><td> Email Id </td><td>: </td><td> <input type="text" name="emailid" value=""></td></tr>
					
					
					</table>
					
					</td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                </table>